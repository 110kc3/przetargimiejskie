// Decorates zgm-gliwice.pl pages with prior-auction info.
//
// Two main paths:
//   1) listing index pages (mieszkalne, garaże, użytkowe, wykaz)
//        → find each Elementor card, parse its address, inject badge+tooltip
//   2) property detail pages (slug URLs like /zygmunta-starego-29-4-23-03-2026-r/)
//        → inject a sidebar/panel with the full historical timeline
//
// All user-facing strings go through window.ZGM_I18N.t() so the PL/EN toggle
// in the popup retranslates everything live. We listen on storage changes and
// re-render when the language flips.

(async function () {
  const path = location.pathname;
  const isListingIndex =
    /^\/(przetargi-lokale-mieszkalne|przetargi-garaze|przetargi-lokale-uzytkowe|wykaz-lokali-przeznaczonych-do-sprzedazy-w-przetargu)\/?/.test(
      path,
    );
  const isDetail = /^\/[a-z0-9-]+-\d{2}-\d{2}-\d{4}-r\/?$/.test(path);
  if (!isListingIndex && !isDetail) return;

  // Wait for i18n to load the user's saved language before first render.
  await window.ZGM_I18N.ready;

  let payload;
  try {
    const res = await chrome.runtime.sendMessage({ type: 'getData' });
    if (!res?.ok) throw new Error(res?.error || 'unknown');
    payload = res.payload;
  } catch (err) {
    console.warn('[ZGM ext] failed to load data:', err);
    return;
  }

  const properties = payload.properties?.properties || [];
  const byKey = new Map(properties.map((p) => [p.key, p]));

  function render() {
    // Clear anything we previously injected so re-renders don't duplicate DOM.
    for (const el of document.querySelectorAll('.zgm-ext-badge, .zgm-ext-panel, .zgm-ext-infochip, .zgm-ext-perm2')) {
      el.remove();
    }
    if (isListingIndex) decorateIndex(byKey);
    if (isDetail) decorateDetail(byKey);
  }

  render();
  window.ZGM_I18N.onChange(render);
})();

// -------------------------------------------------------------- index page

function decorateIndex(byKey) {
  const t = window.ZGM_I18N.t;
  const boxes = document.querySelectorAll('.elementor-image-box-content');
  let decorated = 0;
  for (const box of boxes) {
    const text = box.textContent.replace(/\s+/g, ' ').trim();
    const m = /^(.+?)\s+-\s+\d{2}\.\d{2}\.\d{4}\s*r\./.exec(text);
    if (!m) continue;
    const addrRaw = m[1].trim();
    const addr = window.ZGM_NORMALIZE.parseAddress(addrRaw);
    if (!addr) continue;
    const prop = byKey.get(addr.key);
    const prior = prop
      ? prop.listings.filter(
          (l) => l.outcome !== 'active' && l.outcome !== 'announced',
        )
      : [];

    // Area + current price come straight from the card text.
    const { area_m2, price_pln } = parseCardFigures(text);

    // (a) zł/m² inline, right after the price in the description line.
    if (area_m2 && price_pln) {
      const desc = box.querySelector('.elementor-image-box-description');
      if (desc && !desc.querySelector('.zgm-ext-perm2')) {
        const span = document.createElement('span');
        span.className = 'zgm-ext-perm2';
        span.textContent = ' (' + fmtPerM2(price_pln, area_m2) + ')';
        desc.appendChild(span);
      }
    }

    // (b) a small chip with the wadium / viewing dates, if known.
    const activeListing = prop?.listings.find((l) => l.outcome === 'active');
    const datesChip = buildDatesChip(activeListing);
    if (datesChip) box.appendChild(datesChip);

    // (c) prior-history badge.
    if (prior.length === 0) {
      box.appendChild(makeBadge({ kind: 'fresh', text: t('badge.first') }));
    } else {
      const unsoldCount = prior.filter((l) => l.outcome === 'unsold').length;
      const soldCount = prior.filter((l) => l.outcome === 'sold').length;
      const kind =
        unsoldCount >= 2 ? 'red' : unsoldCount === 1 ? 'amber' : 'gray';
      let label;
      if (unsoldCount > 0) {
        const sold_clause = soldCount
          ? t('badge.prev_unsold.sold_clause', { sold: soldCount })
          : '';
        label = t('badge.prev_unsold', {
          n: prior.length,
          unsold: unsoldCount,
          sold_clause,
        });
      } else {
        label = t('badge.prev_sold', { n: prior.length });
      }
      const badge = makeBadge({ kind, text: label });
      // Pass the card-parsed area as a fallback so the history table can
      // still compute zł/m² even when the dataset's per-listing area is null.
      badge.appendChild(buildTooltip(prop, area_m2));
      box.appendChild(badge);
    }
    decorated++;
  }
  console.log(`[ZGM ext] decorated ${decorated} listing card(s)`);
}


// Parses "<addr> - DD.MM.YYYY r. <area> m2 - <price> zł" card text into
// { area_m2, price_pln } (either may be null).
function parseCardFigures(text) {
  const m = /(\d{1,4}(?:[,.]\d{1,3})?)\s*m[²2]\s*-\s*([\d.,\s]+)\s*z[łl]/i.exec(text);
  if (!m) return { area_m2: null, price_pln: null };
  const area = Number(m[1].replace(',', '.'));
  const price = Number(m[2].replace(/[.\s]/g, '').replace(',', '.'));
  return {
    area_m2: Number.isFinite(area) ? area : null,
    price_pln: Number.isFinite(price) ? Math.round(price) : null,
  };
}

// Small chip with the wadium + viewing dates for an active listing.
// Returns null when neither date is known (so we don't inject an empty box).
function buildDatesChip(activeListing) {
  const t = window.ZGM_I18N.t;
  const parts = [];
  if (activeListing?.wadium_deadline) {
    parts.push(`${t('popup.label.wadium')}: ${activeListing.wadium_deadline}`);
  }
  if (activeListing?.viewing_date) {
    parts.push(`${t('popup.label.viewing')}: ${activeListing.viewing_date}`);
  }
  if (!parts.length) return null;
  const chip = document.createElement('div');
  chip.className = 'zgm-ext-infochip';
  chip.textContent = parts.join('  ·  ');
  return chip;
}

function makeBadge({ kind, text }) {
  const el = document.createElement('div');
  el.className = `zgm-ext-badge zgm-ext-${kind}`;
  el.textContent = text;
  return el;
}

function buildTooltip(prop, fallbackArea) {
  const t = window.ZGM_I18N.t;
  const tip = document.createElement('div');
  tip.className = 'zgm-ext-tooltip';
  const table = document.createElement('table');
  table.innerHTML = `
    <thead>
      <tr>
        <th>${t('col.date')}</th>
        <th>${t('col.start_price')}</th>
        <th>${t('col.price_per_m2')}</th>
        <th>${t('col.outcome')}</th>
        <th>${t('col.note')}</th>
      </tr>
    </thead>
    <tbody>
    ${prop.listings
      .filter((l) => l.outcome !== 'active' && l.outcome !== 'announced')
      .map(
        (l) => `
        <tr class="zgm-ext-row-${l.outcome}">
          <td>${l.date ?? '?'}</td>
          <td>${fmtPLN(l.starting_price_pln)}</td>
          <td>${fmtPerM2(l.starting_price_pln, l.area_m2 ?? prop.area_m2 ?? fallbackArea)}</td>
          <td>${outcomeLabel(l)}</td>
          <td>${noteCell(l)}</td>
        </tr>`,
      )
      .join('')}
    </tbody>`;
  tip.appendChild(table);
  return tip;
}

// -------------------------------------------------------------- detail page

function decorateDetail(byKey) {
  const t = window.ZGM_I18N.t;
  // Title is authoritative; slug fallback only.
  let guess = null;
  const titleM = /^([^–—\-]+?)\s+[–—-]/.exec(document.title.replace(/&#8211;/g, '–'));
  if (titleM) guess = titleM[1].trim();
  let addr = guess ? window.ZGM_NORMALIZE.parseAddress(guess) : null;
  if (!addr) {
    guess = window.ZGM_NORMALIZE.addressFromSlug(location.pathname);
    addr = guess ? window.ZGM_NORMALIZE.parseAddress(guess) : null;
  }
  if (!addr) return;
  const prop = byKey.get(addr.key);
  if (!prop) {
    injectPanel({
      title: t('panel.title', { addr: guess }),
      body: `<p>${t('panel.none')}</p>`,
      watchKey: addr.key,
      watchMeta: { addr: guess, kind: 'unknown', detail_url: location.href },
    });
    return;
  }
  const prior = prop.listings.filter(
    (l) => l.outcome !== 'active' && l.outcome !== 'announced',
  );
  const active = prop.listings.find((l) => l.outcome === 'active');
  const rows = prior
    .map(
      (l) => `
      <tr class="zgm-ext-row-${l.outcome}">
        <td>${l.date ?? '?'}</td>
        <td>${kindLabel(l.kind)}</td>
        <td>${fmtPLN(l.starting_price_pln)}</td>
        <td>${fmtPerM2(l.starting_price_pln, l.area_m2 ?? prop.area_m2)}</td>
        <td>${outcomeLabel(l)}</td>
        <td>${l.outcome === 'sold' ? fmtPLN(l.final_price_pln) : ''}</td>
        <td>${l.outcome === 'sold' ? '' : reasonLabel(l.unsold_reason)}</td>
        <td>${l.source_pdf ? `<a target="_blank" rel="noopener" href="${l.source_pdf}">PDF</a>` : ''}</td>
      </tr>`,
    )
    .join('');
  const summary = priceSummary(active, prior);
  injectPanel({
    watchKey: prop.key,
    watchMeta: {
      addr: `${prop.street} ${prop.building}${prop.apt ? '/' + prop.apt : ''}`,
      kind: prop.kind,
      detail_url: location.href,
    },
    title: t('panel.title', {
      addr: `${prop.street} ${prop.building}${prop.apt ? '/' + prop.apt : ''}`,
    }),
    body: `
      ${summary}
      <table class="zgm-ext-history">
        <thead><tr>
          <th>${t('col.date')}</th>
          <th>${t('col.kind')}</th>
          <th>${t('col.start_price')}</th>
          <th>${t('col.price_per_m2')}</th>
          <th>${t('col.outcome')}</th>
          <th>${t('col.final')}</th>
          <th>${t('col.reason')}</th>
          <th>${t('col.src')}</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>`,
  });
}

function priceSummary(active, prior) {
  const t = window.ZGM_I18N.t;
  if (!active || prior.length === 0) return '';
  const first = prior[0];
  const startPrice = active.starting_price_pln;
  if (!first?.starting_price_pln || !startPrice) return '';
  const delta = startPrice - first.starting_price_pln;
  const pct = ((delta / first.starting_price_pln) * 100).toFixed(1);
  const sign = delta >= 0 ? '+' : '−';
  const unsoldCount = prior.filter((l) => l.outcome === 'unsold').length;
  const key = prior.length === 1 ? 'panel.summary_one' : 'panel.summary_many';
  let html = `<p class="zgm-ext-summary">${t(key, {
    n: prior.length,
    unsold: unsoldCount,
    ask: fmtPLN(startPrice),
    date: first.date,
    first: fmtPLN(first.starting_price_pln),
    sign,
    delta: fmtPLN(Math.abs(delta)),
    pct: Math.abs(Number(pct)).toFixed(1),
  })}</p>`;
  const area = active.area_m2 ?? first.area_m2;
  if (area) {
    const askM2 = Math.round(startPrice / area);
    const firstM2 = Math.round(first.starting_price_pln / area);
    const deltaAbs = Math.abs(askM2 - firstM2);
    html += `<p class="zgm-ext-summary">${t('panel.summary_m2', {
      ask_m2: fmtPerM2(startPrice, area),
      first_m2: fmtPerM2(first.starting_price_pln, area),
      sign,
      delta_m2: new Intl.NumberFormat('pl-PL', { maximumFractionDigits: 0 }).format(deltaAbs) + ' zł/m²',
    })}</p>`;
  }
  return html;
}

function injectPanel({ title, body, watchKey, watchMeta }) {
  const t = window.ZGM_I18N.t;
  const wrap = document.createElement('aside');
  wrap.className = 'zgm-ext-panel';
  wrap.innerHTML = `
    <div class="zgm-ext-panel-head">
      <h3>${title}</h3>
      ${watchKey ? `<button type="button" class="zgm-ext-watch" data-key="${watchKey}">…</button>` : ''}
    </div>
    ${body}
    <p class="zgm-ext-footer">
      ${t('panel.footer_data')}
      <a target="_blank" rel="noopener" href="https://github.com/110kc3/zgm-gliwice">110kc3/zgm-gliwice</a>
    </p>`;
  const target =
    document.querySelector('.page-content-container') ||
    document.querySelector('main') ||
    document.body;
  target.insertBefore(wrap, target.firstChild);

  if (watchKey) {
    const btn = wrap.querySelector('.zgm-ext-watch');
    const refresh = async () => {
      const watched = await window.ZGM_WATCH.isWatched(watchKey);
      btn.textContent = watched ? '★ ' + t('watch.button.remove') : '☆ ' + t('watch.button.add');
      btn.classList.toggle('zgm-ext-watch-on', watched);
    };
    refresh();
    btn.addEventListener('click', async () => {
      const watched = await window.ZGM_WATCH.isWatched(watchKey);
      if (watched) await window.ZGM_WATCH.unwatch(watchKey);
      else await window.ZGM_WATCH.watch(watchKey, watchMeta || {});
      refresh();
    });
    // Re-render on lang change (already handled at the page level)
    // and on cross-tab watchlist edits.
    window.ZGM_WATCH.onChange(refresh);
  }
}

// -------------------------------------------------------------- utils

function fmtPLN(n) {
  if (n == null) return '—';
  return (
    new Intl.NumberFormat('pl-PL', { maximumFractionDigits: 0 }).format(n) +
    ' zł'
  );
}

// Returns "X NNN zł/m²" or '—' if either value is missing.
function fmtPerM2(price, area) {
  if (price == null || area == null || area === 0) return '—';
  const v = Math.round(price / area);
  return new Intl.NumberFormat('pl-PL', { maximumFractionDigits: 0 }).format(v) + ' zł/m²';
}


function outcomeLabel(l) {
  const t = window.ZGM_I18N.t;
  if (l.outcome === 'sold') return t('outcome.sold');
  if (l.outcome === 'unsold') return t('outcome.unsold');
  if (l.outcome === 'no_winner') return t('outcome.no_winner');
  return l.outcome;
}

function reasonLabel(reason) {
  const t = window.ZGM_I18N.t;
  if (!reason) return '';
  return t('reason.' + reason, { default: reason });
}

function kindLabel(kind) {
  const t = window.ZGM_I18N.t;
  if (!kind) return '';
  return t('kind.' + kind);
}

function noteCell(l) {
  // For the tooltip on index pages: show "sold ${price}" or the unsold reason.
  const t = window.ZGM_I18N.t;
  if (l.outcome === 'sold') {
    return t('outcome.sold_for', { price: fmtPLN(l.final_price_pln) });
  }
  return reasonLabel(l.unsold_reason);
}
